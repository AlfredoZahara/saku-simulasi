package com.example.sakusimulasi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF102A56)
private val Blue = Color(0xFF1769E8)
private val PaleBlue = Color(0xFFEAF2FF)
private val Ink = Color(0xFF17243A)
private val Muted = Color(0xFF7B8798)
private val Page = Color(0xFFF5F7FB)
private val Green = Color(0xFF159B69)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("saku_demo", MODE_PRIVATE)
        setContent {
            var balance by remember { mutableLongStateOf(prefs.getLong("balance", 1250000L)) }
            var showBalance by remember { mutableStateOf(true) }
            var editDialog by remember { mutableStateOf(false) }
            var balanceInput by remember { mutableStateOf("") }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Blue,
                    background = Page,
                    surface = Color.White,
                    onBackground = Ink,
                    onSurface = Ink
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Page) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 28.dp)
                    ) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Navy)
                                    .padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 28.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                                            .background(Color.White.copy(alpha = .14f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Wallet, null, tint = Color.White)
                                    }
                                    Spacer(Modifier.width(11.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("SAKU", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                                        Text("Dompet digital simulasi", color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
                                    }
                                    Icon(Icons.Default.NotificationsNone, null, tint = Color.White, modifier = Modifier.size(25.dp))
                                }
                                Spacer(Modifier.height(25.dp))
                                Text("Halo, Farhan 👋", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(5.dp))
                                Text("Ini ringkasan dompet virtual kamu", color = Color.White.copy(alpha = .72f), fontSize = 12.sp)
                                Spacer(Modifier.height(20.dp))
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(22.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White)
                                ) {
                                    Column(Modifier.padding(19.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("TOTAL SALDO SIMULASI", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                                            Icon(
                                                if (showBalance) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                contentDescription = "Tampilkan saldo",
                                                tint = Muted,
                                                modifier = Modifier.size(20.dp).clickable { showBalance = !showBalance }
                                            )
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Text(
                                            if (showBalance) rupiah(balance) else "••••••••",
                                            color = Navy, fontSize = 29.sp, fontWeight = FontWeight.Bold
                                        )
                                        Spacer(Modifier.height(14.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(color = PaleBlue, shape = RoundedCornerShape(8.dp), modifier = Modifier.clickable {
                                                balanceInput = balance.toString()
                                                editDialog = true
                                            }) {
                                                Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Edit, null, tint = Blue, modifier = Modifier.size(14.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("Edit saldo virtual", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                            Spacer(Modifier.weight(1f))
                                            Text("BUKAN SALDO ASLI", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Column(Modifier.padding(horizontal = 20.dp)) {
                                Spacer(Modifier.height(18.dp))
                                Text("Menu utama", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    MenuTile("Top up", Icons.Default.AddCard, Modifier.weight(1f))
                                    MenuTile("Kirim", Icons.Default.Send, Modifier.weight(1f))
                                    MenuTile("Bayar", Icons.Default.QrCode, Modifier.weight(1f))
                                    MenuTile("Lainnya", Icons.Default.GridView, Modifier.weight(1f))
                                }
                                Spacer(Modifier.height(22.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Aktivitas terbaru", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text("SIMULASI", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(10.dp))
                                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column {
                                        TransactionRow(Icons.Default.ArrowDownward, "Top up simulasi", "Hari ini · 09.30", "+ Rp500.000", Green)
                                        HorizontalDivider(color = Color(0xFFF0F2F6), modifier = Modifier.padding(start = 60.dp))
                                        TransactionRow(Icons.Default.ShoppingBag, "Belanja simulasi", "Kemarin · 18.15", "- Rp75.000", Ink)
                                        HorizontalDivider(color = Color(0xFFF0F2F6), modifier = Modifier.padding(start = 60.dp))
                                        TransactionRow(Icons.Default.Send, "Kirim simulasi", "16 Nov · 14.02", "- Rp25.000", Ink)
                                    }
                                }
                                Spacer(Modifier.height(18.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PaleBlue).padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, null, tint = Blue, modifier = Modifier.size(19.dp))
                                    Spacer(Modifier.width(9.dp))
                                    Text("Aplikasi latihan. Tidak terhubung ke bank, DANA, atau sistem pembayaran apa pun.", color = Navy, fontSize = 10.sp, lineHeight = 15.sp)
                                }
                            }
                        }
                    }

                    if (editDialog) {
                        AlertDialog(
                            onDismissRequest = { editDialog = false },
                            title = { Text("Edit saldo virtual") },
                            text = {
                                Column {
                                    Text("Masukkan nominal saldo simulasi dalam Rupiah.", color = Muted, fontSize = 13.sp)
                                    Spacer(Modifier.height(12.dp))
                                    OutlinedTextField(
                                        value = balanceInput,
                                        onValueChange = { balanceInput = it.filter(Char::isDigit).take(15) },
                                        label = { Text("Nominal saldo") },
                                        prefix = { Text("Rp ") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text("Perubahan hanya tersimpan di perangkat ini.", color = Muted, fontSize = 11.sp)
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    balanceInput.toLongOrNull()?.let {
                                        balance = it
                                        prefs.edit().putLong("balance", it).apply()
                                    }
                                    editDialog = false
                                }) { Text("Simpan") }
                            },
                            dismissButton = { TextButton(onClick = { editDialog = false }) { Text("Batal") } }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(vertical = 15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(43.dp).clip(CircleShape).background(PaleBlue), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TransactionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, amount: String, amountColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(37.dp).clip(CircleShape).background(PaleBlue), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Text(subtitle, fontSize = 10.sp, color = Muted)
        }
        Text(amount, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = amountColor)
    }
}

private fun rupiah(value: Long): String {
    return NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(value)
        .replace(",00", "")
}
