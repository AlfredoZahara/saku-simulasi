# Saku Simulasi — Android

Aplikasi latihan dompet digital fiktif berbasis Kotlin + Jetpack Compose.

## Fitur
- Dashboard saldo virtual
- Tampilkan/sembunyikan saldo
- Edit nominal saldo
- Penyimpanan lokal menggunakan SharedPreferences
- Riwayat transaksi contoh yang diberi label simulasi

## Cara membuka
1. Ekstrak ZIP.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `SakuSimulasiAndroid`.
4. Tunggu Gradle Sync selesai.
5. Jalankan ke emulator atau HP Android dengan USB debugging aktif.

Memerlukan Android Studio versi baru, JDK 17, dan koneksi internet saat Gradle mengunduh dependensi pertama kali.

Aplikasi ini adalah demo fiktif. Tidak memakai merek, logo, API, atau sistem pembayaran DANA dan tidak memproses uang sungguhan.
